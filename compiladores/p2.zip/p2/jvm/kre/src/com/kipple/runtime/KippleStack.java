package com.kipple.runtime;

public final class KippleStack extends BaseStack {

}
