How to run generator from WIRTH:

python3 -m generator