void initCode();
void printCode();
void saveCodeToFile(char *outputPath);

void addCode(const char *line);
