#include "../main.h"
#include "../semantico.h"

void consumeTransition(CodeGeneratorTransition *transition);
void initCodeGenerator();
void printCode();
