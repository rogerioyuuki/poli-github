char *getTempVar();
