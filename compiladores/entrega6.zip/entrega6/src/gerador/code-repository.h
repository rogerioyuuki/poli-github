void initCode();
void printCode();
void saveCodeToFile(char *outputPath);

void addToDataArea(const char *line);
void addToCodeArea(const char *line);
