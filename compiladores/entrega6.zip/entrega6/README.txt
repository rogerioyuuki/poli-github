COMPILADOR
------------------------
Instrução de compilação:

1) Ter 'flex' instalado na máquina
2) Rodar python3 -m syntax.generator (OPCIONAL)
3) Executar o Makefile ('make')


EXECUÇÂO
--------------------------
Instrução de execução

Na pasta bin/ encontram-se os arquivos necessários para execução da MVN.

Há um arquivo 'fatorial.brl', contendo o código BIRL++.

Há um arquivo Makefile para compilação do 'fatorial.brl' em 'fatorial.mvn'.

O arquivo 'fatorial.mvn' pode ser executado na MVN 'mvn.jar'.



1) Dentro da pasta bin/ rodar o 'make'
2) Para rodar MVN: 'make run'
3) Para carregar o programa: 'p fatorial.mvn'
4) Para rodar o programa: 'r'
